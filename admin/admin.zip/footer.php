<div class="w3-container w3-teal">
 <div class="w3-row">
 <div class="w3-col m12">
 <p>&copy; <?php echo date('Y');?>. iLander Technologies Pvt Ltd. All rights reserved</p>
 </div>
 </div>
</div>