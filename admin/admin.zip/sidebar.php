<?php
include('config.php');
	 
	  $employee_id=$_SESSION['admin_id'];
	  $employee_photo="";
	  $employee_name="";
	  if($conn)
	   {
		   $sql=$conn->prepare('SELECT * FROM employee_login WHERE employee_login_id=?');
		   $sql->bindParam(1,$employee_id);
		  
		   if($sql->execute())
		   {
			 $count=$sql->rowCount();
			 if($count>0)
			 {
				$row=$sql->fetch(PDO::FETCH_OBJ); 
				$employee_photo=$row->employee_photo;
				$employee_name=$row->employee_full_name;
				
			 }
				 
		   }
		   
		}
	
echo '
	<div class="w3-container">
  <div class="w3-card-4">
    <div class="w3-container">
	<img src="images/male.png" class="w3-center w3-circle" alt="Person" style="width:150px">
      
    </div>
    <p class="w3-btn-block w3-light-blue">'.$employee_name.'</p>
  </div>
</div>
	
	
	';



	?> 



 
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
 
 <div class="w3-accordion w3-light-blue">
    <button onclick="myFunction('Demo1')" class="w3-btn-block w3-left-align w3-deep-purple">
	<i class="glyphicon glyphicon-user w3-padding"></i>Personal 
	</button>
	
    <div id="Demo1" class="w3-accordion-content w3-container w3-show">
        <ul class="w3-ul">
   
    <li><a href="change-password.php">Change Password</a></li>
  </ul>
    </div>
	<button onclick="myFunction('Demo3')" class="w3-btn-block w3-left-align w3-deep-purple">
	<i class="glyphicon glyphicon-usd w3-padding"></i>Projects</button>
    <div id="Demo3" class="w3-accordion-content w3-container w3-show">
       <ul class="w3-ul">
    <li><a href="add-leads.php">Add Leads</a></li>
    <li><a href="view-leads.php">View Leads</a></li>
    <li><a href="ongoing.php">Ongoing Projects</a></li>
  </ul>
    </div>
    <button onclick="myFunction('Demo2')" class="w3-btn-block w3-left-align w3-deep-purple">
	<i class="glyphicon glyphicon-file w3-padding"></i>Employees</button>
    <div id="Demo2" class="w3-accordion-content w3-container w3-show">
        <ul class="w3-ul">
    <li><a href="add-employees.php" >Add Employees</a></li>
    <li><a href="view-employees.php" >View Employees</a></li>
    <li><a href="upload-offer.php">Offer Letter</a></li>
    <li><a href="upload-appointment.php">Appointment Letter</a></li>
    <li><a>Monthly Payslips</a></li>
  </ul>
    </div>
	
	<button onclick="myFunction('Demo4')" class="w3-btn-block w3-left-align w3-deep-purple">
	<i class="glyphicon glyphicon-tasks w3-padding"></i>
	Daily Work</button>
    <div id="Demo4" class="w3-accordion-content w3-container w3-show">
       <ul class="w3-ul">
  
    <li><a href="work-details.php">Work Details</a></li>
    
  </ul>
    </div>
	
  </div>
  <script>
function myFunction(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
</script>