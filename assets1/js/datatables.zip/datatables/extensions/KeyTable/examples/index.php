<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" type="image/ico" href="http://www.datatables.net/favicon.ico">
	<meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
	<link rel="stylesheet" type="text/css" href="../../../examples/resources/syntax/shCore.css">
	<link rel="stylesheet" type="text/css" href="../../../examples/resources/demo.css">
	<script type="text/javascript" language="javascript" src="../../../media/js/jquery.js"></script>
	<script type="text/javascript" language="javascript" src="../../../examples/resources/syntax/shCore.js"></script>
	<script type="text/javascript" language="javascript" src="../../../examples/resources/demo.js"></script>

	<title>KeyTable examples - KeyTable examples</title>
</head>

<body class="dt-example">
	<div class="container">
		<section>
			<h1>KeyTable example <span>KeyTable examples</span></h1>

			<div class="info">
				<p>KeyTable provides enhanced accessibility and navigation options for DataTables enhanced tables, by
				allowing Excel like cell navigation on any table. Events (focus, blur, action etc) can be assigned to
				individual cells, columns, rows or all cells to allow advanced interaction options.. Key features
				include:</p>

				<ul class="markdown">
					<li>Easy to use spreadsheet like interaction</li>
					<li>Fully integrated with DataTables</li>
					<li>Wide range of supported events</li>
					<li>Works without DataTables if you just want a plain table</li>
				</ul>
			</div>
		</section>
	</div>

	<section>
		<div class="footer">
			<div class="gradient"></div>

			<div class="liner">
				<div class="toc">
					<div class="toc-group">
						<h3><a href="./index.php">Examples</a></h3>
						<ul class="toc">
							<li><a href="./simple.php">Basic initialisation</a></li>
							<li><a href="./events.php">Events</a></li>
							<li><a href="./scrolling.php">Scrolling table</a></li>
							<li><a href="./html.php">Plain HTML table</a></li>
						</ul>
					</div>
				</div>

				<div class="epilogue">
					<p>Please refer to the <a href="http://www.datatables.net">DataTables documentation</a> for full
					information about its API properties and methods.<br>
					Additionally, there are a wide range of <a href="http://www.datatables.net/extras">extras</a> and
					<a href="http://www.datatables.net/plug-ins">plug-ins</a> which extend the capabilities of
					DataTables.</p>

					<p class="copyright">DataTables designed and created by <a href=
					"http://www.sprymedia.co.uk">SpryMedia Ltd</a> &#169; 2007-2014<br>
					DataTables is licensed under the <a href="http://www.datatables.net/mit">MIT license</a>.</p>
				</div>
			</div>
		</div>
	</section>
</body>
</html>