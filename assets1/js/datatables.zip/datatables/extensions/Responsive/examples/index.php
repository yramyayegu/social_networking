<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" type="image/ico" href="http://www.datatables.net/favicon.ico">
	<meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
	<link rel="stylesheet" type="text/css" href="../../../examples/resources/syntax/shCore.css">
	<link rel="stylesheet" type="text/css" href="../../../examples/resources/demo.css">
	<script type="text/javascript" language="javascript" src="../../../examples/resources/syntax/shCore.js"></script>
	<script type="text/javascript" language="javascript" src="../../../examples/resources/demo.js"></script>

	<title>Responsive examples - Responsive DataTables</title>
</head>

<body class="dt-example">
	<div class="container">
		<section>
			<h1>Responsive example <span>Responsive DataTables</span></h1>

			<div class="info"></div>
		</section>
	</div>

	<section>
		<div class="footer">
			<div class="gradient"></div>

			<div class="liner">
				<div class="toc">
					<div class="toc-group">
						<h3><a href="./initialisation/index.php">Basic initialisation</a></h3>
						<ul class="toc">
							<li><a href="./initialisation/className.php">Class name</a></li>
							<li><a href="./initialisation/option.php">Configuration option</a></li>
							<li><a href="./initialisation/new.php">`new` constructor</a></li>
							<li><a href="./initialisation/ajax.php">Ajax data</a></li>
							<li><a href="./initialisation/default.php">Default initialisation</a></li>
						</ul>
					</div>

					<div class="toc-group">
						<h3><a href="./styling/index.php">Styling</a></h3>
						<ul class="toc">
							<li><a href="./styling/bootstrap.php">Bootstrap styling</a></li>
							<li><a href="./styling/foundation.php">Foundation styling</a></li>
							<li><a href="./styling/scrolling.php">Vertical scrolling</a></li>
							<li><a href="./styling/compact.php">Compact styling</a></li>
						</ul>
					</div>

					<div class="toc-group">
						<h3><a href="./display-control/index.php">Display control</a></h3>
						<ul class="toc">
							<li><a href="./display-control/auto.php">Automatic column hiding</a></li>
							<li><a href="./display-control/classes.php">Class control</a></li>
							<li><a href="./display-control/init-classes.php">Assigned class control</a></li>
							<li><a href="./display-control/fixedHeader.php">With FixedHeader</a></li>
							<li><a href="./display-control/complexHeader.php">Complex headers (rowspan / colspan)</a></li>
						</ul>
					</div>

					<div class="toc-group">
						<h3><a href="./child-rows/index.php">Child rows</a></h3>
						<ul class="toc">
							<li><a href="./child-rows/disable-child-rows.php">Disable child rows</a></li>
							<li><a href="./child-rows/column-control.php">Column controlled child rows</a></li>
							<li><a href="./child-rows/right-column.php">Column control - right</a></li>
							<li><a href="./child-rows/whole-row-control.php">Whole row child row control</a></li>
							<li><a href="./child-rows/custom-renderer.php">Custom child row renderer</a></li>
						</ul>
					</div>
				</div>

				<div class="epilogue">
					<p>Please refer to the <a href="http://www.datatables.net">DataTables documentation</a> for full information about its API properties and methods.<br>
					Additionally, there are a wide range of <a href="http://www.datatables.net/extras">extras</a> and <a href="http://www.datatables.net/plug-ins">plug-ins</a>
					which extend the capabilities of DataTables.</p>

					<p class="copyright">DataTables designed and created by <a href="http://www.sprymedia.co.uk">SpryMedia Ltd</a> &#169; 2007-2015<br>
					DataTables is licensed under the <a href="http://www.datatables.net/mit">MIT license</a>.</p>
				</div>
			</div>
		</div>
	</section>
</body>
</html>